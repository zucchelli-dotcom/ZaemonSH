#!/usr/bin/env bash

###############################################################################
# Numbers
###############################################################################

# Hotkey for "File > Export To > CSV…"
defaults write com.apple.iWork.Numbers NSUserKeyEquivalents -dict-add "\033File\033Export To\033CSV…" '^~@s'
