#!/usr/bin/env bash

###############################################################################
# ForkLift
###############################################################################

# Enable ForkLift Mini
xattr -drs com.apple.quarentine /Applications/ForkLift.app
