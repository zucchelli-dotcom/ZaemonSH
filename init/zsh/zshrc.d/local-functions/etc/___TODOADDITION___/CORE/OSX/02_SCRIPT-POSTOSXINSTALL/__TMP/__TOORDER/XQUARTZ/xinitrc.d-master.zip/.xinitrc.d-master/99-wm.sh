#!/bin/sh
exec /usr/local/bin/i3
