# xquartz
settings for xquartz
