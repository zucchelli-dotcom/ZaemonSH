#!/usr/bin/env bash

###############################################################################
# iCloud
###############################################################################

# Save to iCloud by default
defaults write NSGlobalDomain NSDocumentSaveNewDocumentsToCloud -bool true
