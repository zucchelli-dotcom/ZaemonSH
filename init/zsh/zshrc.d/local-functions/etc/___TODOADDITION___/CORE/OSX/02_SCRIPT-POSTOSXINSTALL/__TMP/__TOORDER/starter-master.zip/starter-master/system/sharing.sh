#!/usr/bin/env bash

###############################################################################
# Sharing
###############################################################################

# Set computer name (as done via System Preferences → Sharing)
#sudo scutil --set ComputerName "0x6A796872"
#sudo scutil --set HostName "0x6A796872"
#sudo scutil --set LocalHostName "0x6A796872"
#sudo defaults write /Library/Preferences/SystemConfiguration/com.apple.smb.server \
#    NetBIOSName -string "0x6A796872"
