#!/usr/bin/env bash

###############################################################################
# XScope
###############################################################################

# Disable Dock icon
defaults write com.artissoftware.mac.xScope generalShowDockIcon 0
defaults write com.artissoftware.xScope generalShowDockIcon 0
