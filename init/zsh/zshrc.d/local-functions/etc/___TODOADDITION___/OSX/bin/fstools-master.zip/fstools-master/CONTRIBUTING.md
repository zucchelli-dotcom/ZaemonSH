By submitting a request, you represent that you have the right to license
your contribution to the community, and agree that your contributions are
licensed under the [GNU General Public License Version
2](src/fstorture/LICENSE) (for just the fstorture portions of the FS Tools
project) or the [Apple Public Source License Version 2.0](APPLE_LICENSE)
(for the remainder of the FS Tools project).

For existing files modified by your request, you represent that you have
retained any existing copyright notices and licensing terms. For each new
file in your request, you represent that you have added to the file a
copyright notice (including the year and the copyright owner's name) and the
FS Tools licensing terms.
