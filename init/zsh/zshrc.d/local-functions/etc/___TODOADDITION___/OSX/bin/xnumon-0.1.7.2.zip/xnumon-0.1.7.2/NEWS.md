### xnumon 0.1.7.2 2019-01-27

-   Avoid calling file operations that would block while the kext is blocking
    processes during exec(2); this avoids deadlocking the system while
    long-running low-level disk operation are in progress, such as while Boot
    Camp Assistant is editing partitions or Disk Utility is running fsck.
-   Drop support for OS X 10.11 El Capitan.

---

### xnumon 0.1.7.1 2018-10-08

-   Bugfix release fixing the handling of ptrace(2) for non-`PT_ATTACHEXC`
    requests.

---

### xnumon 0.1.7 2018-09-21

-   The kernel extension is now appropriately signed (issue #6).
-   Build system improvements for alternative Xcode installations, macOS
    min version targeting, SDK selection and kext signing.

---

### xnumon 0.1.6.3 2018-08-26

-   Bugfix release fixing a memory leak in executable image tracking.

---

### xnumon 0.1.6.2 2018-08-05

-   Bugfix release fixing a rare data corruption issue in the audit(4) record
    handling (issue #41).

---

### xnumon 0.1.6.1 2018-08-01

-   Bugfix release fixing a crash in the kext event handling loop of the
    xnumon daemon (issue #36).

---

### xnumon 0.1.6 2018-07-29

-   Capability to log all environment variables at image exec (`full`),
    only log variables affecting dyld (`dyld`) or not log the environment
    (`none`) (issue #7).
-   Add `xml` log format (issue #12).
-   Add capability to omit the `sid` field of processes.
-   Rewritten event loop for improved behaviour under load (issue #33).
-   Use IOKit API instead of `kextload` to load the xnumon kext (issue #17).
-   Check global audit(4) policy settings every five minutes for clobbering
    (issue #35).

Configuration changes:

-   Added `envlevel`.
-   Added `omit_sid`.

Event schema changes:

-   Event schema version increased to 6.  Changes affect eventcode 2.
-   Eventcode 1 added `evtloop.aupclobber`.
-   Eventcode 2 added `env`.

---

### xnumon 0.1.5 2018-07-23

-   Suppressions by ident now support optionally restricting an ident to a
    specific team ID (issue #27).
-   User and group IDs are now by default resolved to names (issues #4, #28).
-   User and group ID -1 is now logged as signed integer -1 instead of unsigned
    integer 4294967295 (issue #29).
-   Extract the `origin` of good signed binaries from the code signature:
    Apple System (`system`), Mac App Store (`appstore`),
    Developer ID (`devid`), other Apple (`generic`) or signature from CA in
    system's Trust Settings database (`trusted`) (issue #31) and align
    algorithm with Gatekeeper.
-   Report code signatures from untrusted CAs as signature `untrusted` with no
    origin instead of signature `bad`.
-   Add capability to omit somewhat less useful fields from logged events:
    file mode, size, mtime, ctime, btime, and groups (file gid and process
    egid/rgid) (issue #3).
-   Treat TTY device `/dev/null` and source address `0.0.0.0` as no device and
    no address respectively and hide the `dev` and `addr` fields accordingly
    unless an actual TTY device or source address is reported by audit(4).
-   Fix automatic configuration reloading to pick up changes to the config file
    during the first five minutes and during initialization.
-   Add metric for the number of processes successfully acquired from live
    process state as part of working around some bug or missed event.
-   Add raw log destination driver mode to facilitate fully custom logging
    within the current log driver model.
-   Add `chkcs` developer utility to extract code signatures from binaries or
    bundles on the command line.

Configuration changes:

-   Extended `suppress_image_exec_by_ident`,
    `suppress_image_exec_by_ancestor_ident` and
    `suppress_process_access_by_subject_ident` to support ident@teamid syntax.
-   Added `resolve_users_groups`.
-   Added `omit_mode`, `omit_size`, `omit_mtime`, `omit_ctime`, `omit_btime`,
    `omit_groups`.

Event schema changes:

-   Event schema version increased to 5.  Changes affect eventcodes 1-4.
-   Eventcode 1 added `procmon.liveacq`.
-   Eventcode 2 added `image.origin`.
-   Eventcode 2 renamed `image.devid` to `image.certcn`.
-   Eventcodes 2-4 added `*uname` for every `*uid` field.
-   Eventcodes 2-4 added `*gname` for every `*gid` field.

---

### xnumon 0.1.4 2018-07-15

-   Add `json-seq` log format, as defined in RFC 7464:  JSON objects are each
    prefixed by an ASCII Record Separator and terminated by an ASCII Line Feed
    character (issue #13).
-   Mark all image execs as well as subject and object processes that were
    reconstructed by pid instead of from audit events with a `reconstructed`
    field.
-   Generate an image exec event for processes that were missed during exec for
    some reason and are reconstructed by pid later on for context.
-   Make configurable whether processes already running at xnumon agent start
    should generate an image exec event (issue #8).
-   Fix text rendering of `signature` field on images.
-   Use travis-ci.com for continuous integration on supported macOS versions
    (issue #24).

Configuration changes:

-   Add `suppress_image_exec_at_start`.

Event schema changes:

-   Event schema version increased to 4.  Changes affect eventcodes 2-4.
-   Eventcode 2 added `reconstructed`.
-   Eventcode 4 added `object.reconstructed`.
-   Eventcodes 2-4 added `subject.reconstructed`.

---

### xnumon 0.1.3 2018-07-07

-   Fix ancestors default if not set from 0 back to unlimited as documented and
    omit ancestors array entirely if ancestors is 0.
-   Suppressions by path now also match the script path, not only the image or
    interpreter path.
-   Add ability to suppress child image exec events by ancestor ident or path
    in order to be able to suppress noisy things like MacPorts builds
    (issue #22).
-   Streamlined signer information from code signatures now includes
    developer ID and team ID instead of the full certificate chain, which
    results in lower heap usage and lower log volume for essentially the same
    information (issue #20).
-   Extract CDHash from code signatures (issue #21).
-   Add ability to omit hashes for Apple-signed binaries, enabled by default
    (issue #2).
-   Verify that signatures on Apple binaries are anchored at the Apple root.

Configuration changes:

-   Rename `suppress_process_access_by_ident` and
    `suppress_process_access_by_path` to
    `suppress_process_access_by_subject_ident` and
    `suppress_process_access_by_subject_path`.
-   Add `suppress_image_exec_by_ancestor_ident` and
    `suppress_image_exec_by_ancestor_path`.
-   Add `omit_apple_hashes`.

Event schema changes:

-   Event schema version increased to 3.  Changes affect eventcodes 1-4.
-   Eventcode 1 replaced `evtloop.needargv`, `evtloop.needcwd` and
    `evtloop.needpath` with `evtloop.radar38845422_fatal`,
    `evtloop.radar39267328_fatal` and `evtloop.radar39623812_fatal`.
-   Eventcode 1 added `evtloop.missingtoken` and `evtloop.radar38845784`.
-   Eventcode 2 replaced `image.codesign.result`, `image.codesign.cert`,
    `image.codesign.chain` with `image.signature`, `image.teamid` and
    `image.devid`.
-   Eventcode 2 added `image.cdhash`.
-   Eventcodes 2-4 added `subject.image.teamid` and
    `subject.ancestors[].teamid`.

---

### xnumon 0.1.2 2018-06-24

-   Fix handling of `ptrace` and `task_for_pid` audit events for pid 0 or -1.
-   Fix default hash if unspecified to be sha256 as documented in the default
    config.

Configuration changes:

-   Add `events` config option to configure the desired eventcodes (issue #1).
-   Add `stats_interval` config option to control how often xnumon-stats[1]
    events are generated.
-   Add `debug` config option to control whether debug messages are logged to
    stderr.
-   Add `reload|restart` target to `xnumonctl`, rename `logstats` to `event1`.

Event schema changes:

-   Event schema version increased to 2.  Changes affect eventcodes 0 and 1.
    Eventcode 0 added config.events, config.stats_interval, config.debug.
    Eventcode 1 removed evtloop.pathbugs, procmon.cwdmiss, procmon.eimiss;
    added evtloop.radar38845422, evtloop.radar39267328, evtloop.radar39623812,
    evtloop.needpath, evtloop.needargv, evtloop.needcwd, procmon.miss.bypid,
    procmon.miss.forksubj, procmon.miss.execsubj, procmon.miss.execinterp,
    procmon.miss.chdirsubj, procmon.miss.getcwd.

---

### xnumon 0.1.1 2018-06-17

-   Fix code signature extraction by using the strictest possible form of
    code signature verification.  Addresses fat binaries containing a
    combination of good and bad Mach-O binaries mistakenly being treated as
    having a good signature, as published by Josh Pitts of okta.
-   Fix installer package scripts for installing on external disks.
-   Harden permissions on default configuration file and directory.

---

### xnumon 0.1.0 2018-06-15

Initial release at [AREA41](//a41con.ch) 2018.
