#!/bin/tcsh -f

##
######################## login-diskimage.sh ########################
# Mike Bombich | mike@bombich.com                
# Copyright 2003 Mike Bombich.     
# Use Loginwindow Manager (http://www.bombich.com/software/lwm.html)
# to make this shell script run each time a user logs in or out.
####################################################################


### Description ###
#
# This script mounts a read-only disk image with a shadow file
# to be used as the user's home directory. When the user logs in
# any previous shadow file is destroyed and the template home
# directory is created by mounting the disk image whose mountpoint
# is the location of the user's home directory.

####  THIS SCRIPT NEEDS SOME ADDITIONAL WORK  ####

## The disk image is not properly unmounted when that user logs out, probably
## need to implement a logout hook as well (is it worth it?)


### Properties ###
#
# These items must be modified to suit your environment before
# implementing this script! You do not need to make any other
# modifications to this file than these properties.
#
# acctInfo: The home directory and uid for the user logging in (calculated by default)
#		You can specify this explicitly with: set acctInfo = (/Users/default 501)
# localAdmin: A local user for whom you do not want an image mounted
# image: location of the image containing the default home directory
# shadow: location to create the shadow file
# set acctInfo = `/usr/sbin/lookupd -q user -a name $1 | awk '/home/||/uid/ { print $2 }'`
set acctInfo="$USER $(dscl . -list /Users UniqueID | awk '{print $2}' | sort -n | tail -1) "
set localAdmin = admin
set image = /Library/Management/default.dmg
set shadow = /private/tmp/${1}_shadow


### Debug/testing sanity check ###
if ( $#argv < 1 ) then
	echo "No user specified!"
	exit 1
endif


### Script action ###
# Delete old shadow files, then create the mountpoint 

# If this is not the admin user, mount the image as the user with a shadow file
# $acctInfo[1] is the home directory, $acctInfo[2] is the uid
if ( ${1} != $localAdmin ) then
	/bin/rm -rf $shadow
	/bin/rm -rf $acctInfo[1]
	/bin/mkdir -m 0777 $acctInfo[1]
	/usr/sbin/chown -R $1 $acctInfo[1]
	/usr/sbin/disktool -c $acctInfo[2]
	set devNum = `/usr/bin/su $1 -c "/usr/bin/hdid -nomount $image -shadow $shadow"`
	/usr/bin/su $1 -c "/sbin/mount -t hfs $devNum[5] $acctInfo[1]"
	/usr/sbin/chown -R $1 $acctInfo[1]
endif


### Always exit with 0 status
exit 0
