#!/bin/tcsh -f

######################### login-byhostfix.sh #######################
# Mike Bombich | mike@bombich.com                
# Copyright 2003 Mike Bombich.     
# Use Loginwindow Manager (http://www.bombich.com/software/lwm.html)
# to make this shell script run each time a user logs in or out.
####################################################################


### Description ###
#
# This script renames items in the ~/Library/Preferences/ByHost
# folder with the HW address of the current machine


### Properties ###
#
# These items must be modified to suit your environment before
# implementing this script! You do not need to make any other
# modifications to this file than these properties.
#
# You can explicitly set the hardware address of your master machine
# here, or you can rely on this one line command to figure it out.
# This method for obtaining the master HW address is probably not rock
# solid so you should strongly consider setting it explicitly
set masterHW = `/bin/ls /Users/$1/Library/Preferences/ByHost | /usr/bin/awk -F. '/com/ { print $4; nextfile }'`


### Debug/testing sanity check ###
if ( $#argv < 1 ) then
	echo "No user specified!"
	exit 1
endif


### Script action ###
set hwAddress = `/sbin/ifconfig en0 | awk '/ether/ { gsub(":", ""); print $2 }'`
cd /Users/$1/Library/Preferences/ByHost
set byHostItems = (`ls -A /Users/$1/Library/Preferences/ByHost`)

foreach item ( $byHostItems )
	if ( `echo $item | grep -c $masterHW` == "1" ) then
		mv $item `echo $item | sed "s/$masterHW/$hwAddress/g"`
	endif
end


### Always exit with 0 status
exit 0
