#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin export PATH

############################ logouttrack.sh ########################
# Mike Bombich | mike@bombich.com
# Copyright 2003 Mike Bombich
# Loginwindow Manager (http://www.bombich.com/software/lwm.html)
####################################################################


### Description ###
#
# This script collects information about the user and posts a
# logout event to a local log and, optionally, to a database
#
###
# This script requires implementation of the logintrack.sh script!
# This script must be run before any home directory maintenance
###

### Properties ###
#
# These items must be modified to suit your environment before
# implementing this script! You do not need to make any other
# modifications to this file than these properties.
#
logfile="/var/log/usertracking.txt"

# Optionally, specify information for connecting to a web-based database
# For example, you could write a php script to enter the data into a MySQL database on a Mac OS X Server
#dbuser="logger"
#dbpass="sekrit"
#dburl="https://xserve.apple.edu/log/logger.php"

# Optionally, specify information to log the message to syslog
# Take a look at http://www.dittomac.com/article.php?story=20041107222004872
# for information on configuring clients to send syslog info to a
# central syslog server and how to set up a syslog server
#priority="local7.notice"
#tag="my_tag"



### Script action ###
# Gather information
username=`cat /Users/default/.username`
hostname=`hostname`
ip=`ipconfig getifaddr en0`
datestamp=`date ''+%m-%d-%Y_%H.%M.%S''` #e.g.: 02-13-2004_16.45.09

# log to text logfile on local machine
echo $username,$datestamp,$hostname,$ip,logout >> "$logfile"
chmod o-rwx "$logfile"

# use curl to (optionally) log the data to a database
#curl -u ${dbuser}:${dbpass} "${dburl}?username=$username&datestamp=$datestamp&hostname=$hostname&ip=$ip&action=logout"

# Send it to syslog (hostname and datestamp are recorded by default in syslog)
# 
#logger -t $tag -p $priority "$username,$ip,logout"
